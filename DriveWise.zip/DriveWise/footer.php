<footer class="text-center fixed-bottom" style="background-color: #2c3333; height: 25px;">
  <div class="text-center" style="color: white;">
    © DRIVE WISE
  </div>
</footer>